package ex13;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.scene.input.MouseEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.*;

public class SubjectDisplayController implements Initializable {
    @FXML Button previous, next;
    @FXML TextField subjectsearch;
    @FXML private ImageView subjectimage;
    @FXML private Label subjectname, subjectunits, subjectgrade;
    
    private Subject display;
    
    @FXML
    private void searchSubject(MouseEvent event) {
        String entry = subjectsearch.getText();
        try {
            Subject searched = Subject.searchSubject(entry);
            displaySubject(searched);
            
        }
        catch(NullPointerException exception) {
            subjectname.setText("Input cannot be found.");
            subjectunits.setText("Enter a valid subject.");
            subjectgrade.setText("e.g. math");
            changeButtonStatus();
            
        }
    
    }
    
    @FXML
    private void previousSubject(MouseEvent event) {
        int index = Subject.getSubjectIndex(display);
        index--;
        Subject prevSubject = Subject.subjectList.get(index);
        display = prevSubject;
        displaySubject(prevSubject);
    }
    
    @FXML
    private void nextSubject(MouseEvent event) {
        int index = Subject.getSubjectIndex(display);
        index++;
        Subject nextSubject = Subject.subjectList.get(index);
        display = nextSubject;
        displaySubject(nextSubject);
        
    }
    
    public void displaySubject(Subject s) {
        display = s;
        Image img = new Image(getClass().getResourceAsStream(s.getImgFileName()));
        subjectname.setText("Name: " + s.getName());
        subjectunits.setText("Units: " + Double.toString(s.getUnits()));
        subjectgrade.setText("Grade: " + Double.toString(s.getGrade()));
        subjectimage.setImage(img);
        changeButtonStatus();
        
    }
    
    public void changeButtonStatus() {
        int index = Subject.getSubjectIndex(display);
        if(index == 0) previous.setDisable(true);
        else previous.setDisable(false);
        if(index == Subject.getListLength() - 1) next.setDisable(true);
        else next.setDisable(false);
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Subject initial = Subject.subjectList.get(0);
        display = initial;
        displaySubject(initial);
    }    
    
}