package ex13;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Ex13 extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Subject bio = new Subject("Biology", "biology.png", 1, 1.00);
        Subject chem = new Subject("Chemistry", "chemistry.png", 2, 1.25);
        Subject comsci = new Subject("Computer Science", "computer science.png", 1, 1.25);
        Subject phys = new Subject("Physics", "physics.png", 1.3, 1.50);
        Subject math = new Subject("Math", "math.png", 1.7, 1.50);
        
        Parent root = FXMLLoader.load(getClass().getResource("SubjectDisplay.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
    
}