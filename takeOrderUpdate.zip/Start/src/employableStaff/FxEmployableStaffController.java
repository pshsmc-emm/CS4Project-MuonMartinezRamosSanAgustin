/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employableStaff;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author MUON
 */
public class FxEmployableStaffController implements Initializable {

    @FXML Button staffExitButton;
    @FXML public void exitStaff(ActionEvent event) throws IOException {
 
            Node node = (Node) event.getSource();
            Scene currentScene = node.getScene();
            Stage currentStage = (Stage) currentScene.getWindow();

            Parent root = FXMLLoader.load(getClass().getResource("/Start/Main.fxml"));

            Scene mainScene = new Scene (root);
            currentStage.hide();
            currentStage.setScene(mainScene);
            currentStage.setTitle("Main");
            currentStage.show();
             
            File file = new File("/Start/employableStaff/staff data sheet.csv");
            FileReader fr = new FileReader(file);
            BufferedReader reader = new BufferedReader(fr);
            
            String line;
            while ((line = reader.readLine()) != null) {
                String[] details = line.split(", ");
                new EmployableStaff (details[0], details[1], Double.parseDouble(details[2]), Double.parseDouble(details[3]));
            }
            reader.close();
            
         
    }
    @FXML ImageView staff1Description;
    @FXML ImageView staff2Description;
    @FXML Text staffDescription;

    
    
    @FXML public void staff1Desc(MouseEvent event) {
        staffDescription.setText("Mary is hardworking and diligent but has social anxiety.");
    }
    @FXML public void staff2Desc(MouseEvent event) {
        staffDescription.setText("Joseph has a positive attitude but was fired from his last job due to mysterious circumstances.");
    }
    @FXML public void descExit(MouseEvent event) {
        staffDescription.setText(" ");
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
