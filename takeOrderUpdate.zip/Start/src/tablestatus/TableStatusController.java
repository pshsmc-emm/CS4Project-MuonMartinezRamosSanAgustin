/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package tablestatus;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author Basti San Agustin
 */
public class TableStatusController implements Initializable {
   
    @FXML Button tableStatusExitButton;
    @FXML public void exitTableStatus(ActionEvent event) throws IOException {
 
            Node node = (Node) event.getSource();
            Scene currentScene = node.getScene();
            Stage currentStage = (Stage) currentScene.getWindow();

            Parent root = FXMLLoader.load(getClass().getResource("/Start/Main.fxml"));

            Scene mainScene = new Scene (root);
            currentStage.hide();
            currentStage.setScene(mainScene);
            currentStage.setTitle("Main");
            currentStage.show();
            
            
    }
    @FXML Text t1cleanlinessDescription;
    @FXML Text t2cleanlinessDescription;
    @FXML Text t3cleanlinessDescription;
    @FXML Text t4cleanlinessDescription;
    @FXML Text t5cleanlinessDescription;
    @FXML Text cleanlinessDescription;

    
    @FXML public void t1Desc(MouseEvent event) {
        cleanlinessDescription.setText("This table is clean and empty.");
    }
    @FXML public void t2Desc(MouseEvent event) {
        cleanlinessDescription.setText("This table is being used and at full occupancy.");
    }
    @FXML public void t3Desc(MouseEvent event) {
        cleanlinessDescription.setText("This table is being used with one available seat.");
    }
    @FXML public void t4Desc(MouseEvent event) {
        cleanlinessDescription.setText("This table is clean and empty.");
    }
    @FXML public void t5Desc(MouseEvent event) {
        cleanlinessDescription.setText("This table is dirty with one available seat.");
    }
    @FXML public void descExit(MouseEvent event) {
        cleanlinessDescription.setText(" ");
    }
       
    @FXML Text t1Occupancy;
    @FXML Text t2Occupancy;
    @FXML Text t3Occupancy;
    @FXML Text t4Occupancy;
    @FXML Text t5Occupancy;
    
    @FXML public void t1OccupancyHighlight(MouseEvent event) {
        t1Occupancy.setFill(Color.GREEN);
    }
    @FXML public void t2OccupancyHighlight(MouseEvent event) {
        t2Occupancy.setFill(Color.RED);
    }
    @FXML public void t3OccupancyHighlight(MouseEvent event) {
        t3Occupancy.setFill(Color.ORANGE);
    }
    @FXML public void t4OccupancyHighlight(MouseEvent event) {
        t4Occupancy.setFill(Color.GREEN);
    }
    @FXML public void t5OccupancyHighlight(MouseEvent event) {
        t5Occupancy.setFill(Color.ORANGE);
    }
    
    @FXML public void tableExit (MouseEvent event) {
        t1Occupancy.setFill(Color.BLACK);
        t2Occupancy.setFill(Color.BLACK);
        t3Occupancy.setFill(Color.BLACK);
        t4Occupancy.setFill(Color.BLACK);
        t5Occupancy.setFill(Color.BLACK);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
