package ModelClasses;

import java.util.ArrayList;

/**
 *
 * @author Martinez, Ramos, San Agustin
 */
public class Customer {
  private String name, imgFileName;
  private boolean isSeniorCitizen;
  private boolean isStudent;
  private String assignedTable = "none";
  public static ArrayList<Customer> customerList = new ArrayList();
  

  public Customer(String n, String i, boolean c, boolean s, String a) {
    name = n;
    imgFileName = i;
    isSeniorCitizen = c;
    isStudent = s;
    assignedTable = a;
    customerList.add(this);
  }

  public String getName() {
    return name;
  }

  public boolean getIsSeniorCitizen() {
    return isSeniorCitizen;
  }

  public boolean getIsStudent() {
    return isStudent;
  }

  public String getAssignedTable() {
    return assignedTable;
  }

  public void giveMoney(Employee e) {
  }

  public void orderFood() {
  }
  
  public static int getCustomerIndex(Customer c) throws NullPointerException {
      if(customerList.contains(c)) return customerList.indexOf(c);
        else throw new NullPointerException();
  }
  public String getImgFileName(){
        return imgFileName;
  }
  public static int getListLength() {
        return customerList.size();
  }

}