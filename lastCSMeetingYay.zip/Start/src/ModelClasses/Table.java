package ModelClasses;

/**
 *
 * @author Martinez, Ramos, San Agustin
 */
public class Table {
  private String tableNum;
  private int capacity;
  private String cleanliness;

  public Table(String t, int c, String b) {
    tableNum = t;
    capacity = c;
    cleanliness = b;
  }

  public String getTableNum() {
    return tableNum;
  }

  public int getCapacity() {
    return capacity;
  }

  public String getCleanliness() {
    return cleanliness;
  }
  
  public int setCapacity() {
      capacity = capacity + 1;
      return capacity;
  }
  
  public void occupy(Table t) {
  }
  public void assignTable() {
      
  }
}