package Start;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import ModelClasses.Customer;
import ModelClasses.Table;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author MUON
 */
public class MainController implements Initializable {
    @FXML Button menuStartButton;
    @FXML public void startMenu(ActionEvent event) throws IOException {
            Node node = (Node) event.getSource();
            Scene currentScene = node.getScene();
            Stage currentStage = (Stage) currentScene.getWindow();

            Parent root = FXMLLoader.load(getClass().getResource("/Menu/Menu.fxml"));

            Scene mainScene = new Scene (root);
            currentStage.hide();
            currentStage.setScene(mainScene);
            currentStage.setTitle("Menu");
            currentStage.show();
    }
    
    @FXML Button staffStartButton;
    @FXML public void startStaff(ActionEvent event) throws IOException {
 
            Node node = (Node) event.getSource();
            Scene currentScene = node.getScene();
            Stage currentStage = (Stage) currentScene.getWindow();

            Parent root = FXMLLoader.load(getClass().getResource("/employableStaff/fxEmployableStaff.fxml"));

            Scene mainScene = new Scene (root);
            currentStage.hide();
            currentStage.setScene(mainScene);
            currentStage.setTitle("Employable Staff");
            currentStage.show();
    }
    
    @FXML Button tableStatusStartButton;
    @FXML public void startTableStatus(ActionEvent event) throws IOException {
 
            Node node = (Node) event.getSource();
            Scene currentScene = node.getScene();
            Stage currentStage = (Stage) currentScene.getWindow();

            Parent root = FXMLLoader.load(getClass().getResource("/tablestatus/tableStatus.fxml"));

            Scene mainScene = new Scene (root);
            currentStage.hide();
            currentStage.setScene(mainScene);
            currentStage.setTitle("Table Status");
            currentStage.show();
    }
    
    @FXML Button mainExitButton;
    @FXML public void exitMain(ActionEvent event) throws IOException {
 
            Node node = (Node) event.getSource();
            Scene currentScene = node.getScene();
            Stage currentStage = (Stage) currentScene.getWindow();

            Parent root = FXMLLoader.load(getClass().getResource("/Start/Start.fxml"));

            Scene mainScene = new Scene (root);
            currentStage.hide();
            currentStage.setScene(mainScene);
            currentStage.setTitle("Start");
            currentStage.show();
    }
    
    @FXML Text order;
    @FXML Button takeOrder;
    
    @FXML public void takeOrder(ActionEvent event) {
        int min = 0;
        int max = 2;
        int n = (int)Math.floor(Math.random() * (max - min + 1) + min);
        int o = (int)Math.floor(Math.random() * (max - min + 1) + min);
        int p = (int)Math.floor(Math.random() * (max - min + 1) + min);
        int q = (int)Math.floor(Math.random() * (max - min + 1) + min);
        int r = (int)Math.floor(Math.random() * (max - min + 1) + min);
        int s = (int)Math.floor(Math.random() * (max - min + 1) + min);

        order.setText("- " + n + " chocolate chip cookie/s \n- " + o + " small latte/s \n- " + p + " medium latte/s \n- " + q + " large latte/s \n- " + r + " small fries \n- " + s + " large fries");
    }
    
    @FXML ImageView customer1;
    
    private Customer display;
    @FXML Button next;
    
    @FXML Button denyOrder;
    
    @FXML public void denyOrder (MouseEvent event){
        customerImage.setImage(null);
        order.setText(" ");
    }
    
    @FXML public void nextCustomer(MouseEvent event) {
        int index = Customer.getCustomerIndex(display);
        index++;
        Customer nextCustomer = Customer.customerList.get(index);
        display = nextCustomer;
        displayCustomer(nextCustomer);
        order.setText(" ");
    }
    public void displayCustomer(Customer c) {
        display = c;
        Image img = new Image(getClass().getResourceAsStream(c.getImgFileName()));
        customerImage.setImage(img);
        changeButtonStatus();
    }
    
    public void changeButtonStatus() {
        int index = Customer.getCustomerIndex(display);
        if(index == Customer.getListLength() - 1) next.setDisable(true);
        else next.setDisable(false);
        
    }
    @FXML Button assignTableButton;
    @FXML public void assignTable(ActionEvent event) throws IOException {
            startTableStatus(event);
    }
    @FXML ImageView customerImage;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Customer initial = Customer.customerList.get(0);
        display = initial;
        displayCustomer(initial);
    }   
    
    


    

   
    
}
